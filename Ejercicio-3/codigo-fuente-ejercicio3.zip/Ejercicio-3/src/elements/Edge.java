package elements;

public class Edge {
	private String id;
	private String to;
	private String from;
	private Attribute attr;
	
	public Edge(String id, String to, String from, Attribute attr) {
		this.id = id;
		this.to = to;
		this.from = from;
		this.attr = attr;
	}
	
	public String write() {
		return ("EDGE: " + "id = " + id + ", " + "to = " + to +", " + "from = " + from + attr.write());
	}
	
	
}
