package elements;

public class NodeG {
	private String id;
	private Attribute attr;
	
	
	public NodeG(String id, Attribute attr) {
		super();
		this.id = id;
		this.attr = attr;
	}
	
	public String write() {
		return ("NODE: " + "id = " + id + attr.write());
	}
	
	
}
