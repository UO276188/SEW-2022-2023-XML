package app;

import java.io.InputStream;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		InputStream stream = System.in;
		Scanner scan = new Scanner(stream);
		
		String gxl, txt= "";

		do{
			System.out.println("Introduce el archivo gxl (.gxl): ");
			gxl = scan.next();
		} while (!gxl.split("\\.")[1].equals("gxl"));
		
		do{
			System.out.println("Introduce el nombre del archivo txt (.txt): ");
			txt = scan.next();
		} while (!txt.split("\\.")[1].equals("txt"));
		
		scan.close();
		Application a = new Application(gxl, txt);
		a.execute();
	}
}
