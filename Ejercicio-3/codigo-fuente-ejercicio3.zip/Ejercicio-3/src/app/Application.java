package app;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import elements.Attribute;
import elements.Edge;
import elements.NodeG;

public class Application {
	
	private String gxlFile;
	private String txtFile;
	private List<String> lines = new ArrayList<>();
	private FileUtil f = new FileUtil();
	
		
	private List<NodeG> n = new ArrayList<>();
	private List<Edge> e = new ArrayList<>();
	
	private String nombreGraph;
	private String edgemode;

	public Application(String xml, String txt) {
		this.gxlFile = xml;
		this.txtFile = txt;
	}

	public void execute() {
		parseFile();
		write();
		System.out.println("Done");
	}

	private void write() {
		open();
		writeDocument();
		f.writeLines(txtFile, lines);
	}

	private void open() {
		lines.add("---------- GRAPH ----------");
		lines.add(nombreGraph + " : " + edgemode);
		lines.add("");
	}

	private void writeDocument() {
		lines.add("NODES ----------------------");
		for (NodeG node :n) {
			lines.add(node.write());
		}
		lines.add("EDGES ----------------------");
		for (Edge edge : e) {
			lines.add(edge.write());
		}
		
		lines.add("");
		lines.add("Sara Mar�a Ram�rez P�rez");
	}
	

	private void parseFile() {
		try {
			FileInputStream gxl = new FileInputStream(gxlFile);
			DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = builderFactory.newDocumentBuilder();
			Document gxlDocument = builder.parse(gxl);
			XPath xPath = XPathFactory.newInstance().newXPath();

			String expression = "//gxl/graph";
			Node graph = (Node) xPath.compile(expression).evaluate(gxlDocument, XPathConstants.NODE);
			nombreGraph = xPath.compile("@id").evaluate(graph);
			edgemode = xPath.compile("@edgemode").evaluate(graph);
			
			NodeList nodes = (NodeList) xPath.compile("node").evaluate(graph, XPathConstants.NODESET);
			NodeList edges = (NodeList) xPath.compile("edge").evaluate(graph, XPathConstants.NODESET);
			
			
			Node currentNode;
			for (int i = 0; i < nodes.getLength(); i++) {
				currentNode = nodes.item(i);
				
				String id = xPath.compile("@id").evaluate(currentNode);
				Node at = (Node) xPath.compile("attr").evaluate(currentNode, XPathConstants.NODE);
				String name = xPath.compile("@name").evaluate(at);
				String value = xPath.compile("string").evaluate(at);
				
				NodeG node = new NodeG(id, new Attribute(name, value));
								
				n.add(node);
			}
			
			
			Node currentEdge;
			for (int i = 0; i < edges.getLength(); i++) {
				currentEdge = edges.item(i);
				
				String id = xPath.compile("@id").evaluate(currentEdge);
				String to = xPath.compile("@to").evaluate(currentEdge);
				String from = xPath.compile("@from").evaluate(currentEdge);
				
				Node at = (Node) xPath.compile("attr").evaluate(currentEdge, XPathConstants.NODE);
				String name = xPath.compile("@name").evaluate(at);
				String value = xPath.compile("int").evaluate(at);
				
				Edge edge = new Edge(id, to, from, new Attribute(name, value));
								
				e.add(edge);
			}
			

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
