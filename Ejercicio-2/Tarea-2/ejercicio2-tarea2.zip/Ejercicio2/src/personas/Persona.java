package personas;

import java.util.ArrayList;
import java.util.List;

public class Persona {

	private String nombre;
	private String apellidos;
	private String fechaNacimiento;
	private String lugarNacimiento;
	private Coordenada coordenadasNacimiento = new Coordenada();
	private String lugarResidencia;
	private Coordenada coordenadasResidencia = new Coordenada();
	private List<String> fotos = new ArrayList<>();
	private List<String> videos = new ArrayList<>();
	private String comentario;
	
	public Persona() {}
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellidos() {
		return apellidos;
	}
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}
	public String getFechaNacimiento() {
		return fechaNacimiento;
	}
	public void setFechaNacimiento(String fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}
	public String getLugarNacimiento() {
		return lugarNacimiento;
	}
	public void setLugarNacimiento(String lugarNacimiento) {
		this.lugarNacimiento = lugarNacimiento;
	}
	public Coordenada getCoordenadasNacimiento() {
		return coordenadasNacimiento;
	}
	public void setCoordenadasNacimiento(Coordenada coordenadasNacimiento) {
		this.coordenadasNacimiento = coordenadasNacimiento;
	}
	public String getLugarResidencia() {
		return lugarResidencia;
	}
	public void setLugarResidencia(String lugarResidencia) {
		this.lugarResidencia = lugarResidencia;
	}
	public Coordenada getCoordenadasResidencia() {
		return coordenadasResidencia;
	}
	public void setCoordenadasResidencia(Coordenada coordenadasResidencia) {
		this.coordenadasResidencia = coordenadasResidencia;
	}
	public List<String> getFotos() {
		return fotos;
	}
	public void setFotos(List<String> fotos) {
		this.fotos = fotos;
	}
	public List<String> getVideos() {
		return videos;
	}
	public void setVideos(List<String> videos) {
		this.videos = videos;
	}
	public String getComentario() {
		return comentario;
	}
	public void setComentario(String comentario) {
		this.comentario = comentario;
	}
	

	
}
