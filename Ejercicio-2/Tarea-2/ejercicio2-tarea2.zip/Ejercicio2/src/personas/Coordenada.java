package personas;

public class Coordenada {

	private String latitud;
	private String longitud;
	private String altitud;
	
	public Coordenada() {}
	
		
	public String getLatitud() {
		return latitud;
	}



	public void setLatitud(String latitud) {
		this.latitud = latitud;
	}



	public String getLongitud() {
		return longitud;
	}



	public void setLongitud(String longitud) {
		this.longitud = longitud;
	}



	public String getAltitud() {
		return altitud;
	}



	public void setAltitud(String altitud) {
		this.altitud = altitud;
	}

}
