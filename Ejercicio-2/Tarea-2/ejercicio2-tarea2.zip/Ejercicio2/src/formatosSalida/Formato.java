package formatosSalida;

import java.util.List;

import personas.Persona;

public interface Formato {

	void open(String xmlFile, String cssFile);
	void writeBody(List<Persona> amigos);
	void close();

}
