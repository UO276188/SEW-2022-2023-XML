package app;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import formatosSalida.Formato;
import formatosSalida.FormatoHtml;
import formatosSalida.FormatoKml;
import formatosSalida.FormatoSvg;
import personas.Persona;



public class Application {
	

	private String xmlFile;
	private String outputFile;
	private String cssFile;
	private List<String> lines = new ArrayList<>();
	private FileUtil f = new FileUtil();
	private List<Persona> amigos = new ArrayList<>();
	
	private Formato formato;

	public Application(String format, String xml, String html, String css) {
		this.xmlFile = xml;
		this.outputFile = html;
		this.cssFile = css;
		this.formato = chooseFormat(format);
	}

	private Formato chooseFormat(String format) {
		switch (format) {
		case "html":
			return new FormatoHtml(lines);
		case "kml":
			return new FormatoKml(lines);
		case "svg":
			return new FormatoSvg(lines);
		default:
			throw new IllegalArgumentException("Unexpected value for format: " + format);
		}
	}

	public void execute() {
		parseFile();
		write();
		System.out.println("Done");
	}

	private void write() {
		formato.open(outputFile, cssFile);
		formato.writeBody(amigos);
		formato.close();
		f.writeLines(outputFile, lines);
	}


	/**
	 * A�ade las personas a la lista de amigos.
	 */
	private void parseFile() {
		try {
			FileInputStream xml = new FileInputStream(xmlFile);
			DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = builderFactory.newDocumentBuilder();
			Document xmlDocument = builder.parse(xml);
			XPath xPath = XPathFactory.newInstance().newXPath();

			String expression = "//persona";
			NodeList nodeList = (NodeList) xPath.compile(expression).evaluate(xmlDocument, XPathConstants.NODESET);
			
			Node currentPersona;
			for (int i = 0; i < nodeList.getLength(); i++) {
				currentPersona = nodeList.item(i);

				Persona persona = new Persona();
				persona.setNombre(xPath.compile("@nombre").evaluate(currentPersona));
				persona.setApellidos(xPath.compile("@apellidos").evaluate(currentPersona));
				persona.setFechaNacimiento(xPath.compile("@fechaNacimiento").evaluate(currentPersona));

				Node datos = (Node) xPath.compile("datos").evaluate(currentPersona, XPathConstants.NODE);
				persona.setLugarNacimiento(xPath.compile("lugarNacimiento").evaluate(datos));
				

				Node coordenadaN = (Node) xPath.compile("coordenadasNacimiento").evaluate(datos, XPathConstants.NODE);
				persona.getCoordenadasNacimiento().setAltitud(xPath.compile("altitud").evaluate(coordenadaN));
				persona.getCoordenadasNacimiento().setLatitud(xPath.compile("latitud").evaluate(coordenadaN));
				persona.getCoordenadasNacimiento().setLongitud(xPath.compile("longitud").evaluate(coordenadaN));
				
				persona.setLugarResidencia(xPath.compile("lugarResidencia").evaluate(datos));
				
				Node coordenadaR = (Node) xPath.compile("coordenadasResidencia").evaluate(datos, XPathConstants.NODE);
				persona.getCoordenadasResidencia().setAltitud(xPath.compile("altitud").evaluate(coordenadaR));
				persona.getCoordenadasResidencia().setLatitud(xPath.compile("latitud").evaluate(coordenadaR));
				persona.getCoordenadasResidencia().setLongitud(xPath.compile("longitud").evaluate(coordenadaR));
				

				NodeList photos = (NodeList) xPath.compile("foto").evaluate(datos, XPathConstants.NODESET);
				NodeList videos = (NodeList) xPath.compile("video").evaluate(datos, XPathConstants.NODESET);

				Node media;
				for (int j = 0; j < photos.getLength(); j++) {
					media = photos.item(j);
					if (media.getFirstChild() != null)
						persona.getFotos().add(media.getFirstChild().getNodeValue());
				}

				for (int j = 0; j < videos.getLength(); j++) {
					media = videos.item(j);
					if (media.getFirstChild() != null)
						persona.getVideos().add(media.getFirstChild().getNodeValue());
				}
				
				persona.setComentario(xPath.compile("comentario").evaluate(datos));
				
				
				amigos.add(persona);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
