package formatosSalida;

import java.util.List;

import personas.Persona;

public class FormatoKml implements Formato {
	

	private List<String> lines;
	
	public FormatoKml (List<String> lines) {
		this.lines = lines;	
	}
	
	@Override
	public void open(String xmlFile, String cssFile) {
		lines.add("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
		lines.add("<kml xmlns=\"http://www.opengis.net/kml/2.2\">");

	}

	
	@Override
	public void writeBody(List<Persona> amigos) {
		lines.add("<Document>");

		for (Persona p : amigos) {
			//Nacimiento
			lines.add("<Placemark>");
			lines.add(String.format("<name>%s %s - %s</name>", p.getNombre(), p.getApellidos(), "Nacimiento"));
			lines.add(String.format("<description>Fecha de nacimiento: %s</description>", p.getFechaNacimiento()));
			lines.add("<Point>");
			lines.add(String.format("<coordinates>%s, %s, %s</coordinates>", p.getCoordenadasNacimiento().getLongitud().replaceAll("," , "."), 
					p.getCoordenadasNacimiento().getLatitud().replaceAll("," , "."),p.getCoordenadasNacimiento().getAltitud().replaceAll("," , ".")));
			lines.add("</Point>");
			lines.add("</Placemark>");
			
			//Residencia
			lines.add("<Placemark>");
			lines.add(String.format("<name>%s %s - %s</name>", p.getNombre(), p.getApellidos(), "Residencia"));
			lines.add(String.format("<description>Fecha de nacimiento: %s</description>", p.getFechaNacimiento()));
			lines.add("<Point>");
			lines.add(String.format("<coordinates>%s, %s, %s</coordinates>", p.getCoordenadasResidencia().getLongitud().replaceAll("," , "."), 
					p.getCoordenadasResidencia().getLatitud().replaceAll("," , "."),p.getCoordenadasResidencia().getAltitud().replaceAll("," , ".")));
			lines.add("</Point>");
			lines.add("</Placemark>");
		}

		lines.add("</Document>");
	}


	@Override
	public void close() {
		lines.add("</kml>");

	}



}
