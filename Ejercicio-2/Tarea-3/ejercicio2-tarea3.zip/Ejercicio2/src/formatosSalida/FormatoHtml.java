package formatosSalida;

import java.util.List;

import personas.Coordenada;
import personas.Persona;

public class FormatoHtml implements Formato {
	
	private List<String> lines;
	
	public FormatoHtml (List<String> lines) {
		this.lines = lines;	
	}

	@Override
	public void open(String xmlFile, String cssFile) {
		lines.add("<!DOCTYPE HTML>");
		lines.add("<html lang=\"es\">");
		head(xmlFile, cssFile);
	}

	private void head(String xmlFile, String cssFile) {
		lines.add("<head>");
		lines.add("<meta charset=\"UTF-8\" />");
		String titulo = xmlFile.split("\\.")[0];
		lines.add("<title>" + titulo + "</title>");
		lines.add("<meta name=\"autor\" content=\"Sara Mar�a Rm�rez P�rez\"/>");
		lines.add("<meta name =\"viewport\" content =\"width=device-width, initial-scale=1.0\" />");
		lines.add("<link rel=\"stylesheet\" type=\"text/css\" href=\""+ cssFile+"\" />");
		lines.add("</head>");
	}
	
	@Override
	public void writeBody(List<Persona> amigos) {
		lines.add("<body>");
		lines.add("<h1>Red Social</h1>");

		for (Persona persona : amigos) {
			writePersona(persona);
		}

		lines.add("</body>");
	}


	@Override
	public void close() {
		lines.add("</html>");
	}
	

	private void writePersona(Persona p) {
		lines.add("<h2>" + p.getNombre() + " " + p.getApellidos() + "</h2>");
		lines.add("<p>Nacimiento: " + p.getFechaNacimiento() + ", " + p.getLugarNacimiento() + "</p>");
		writeCoordenada(p.getCoordenadasNacimiento());
		
		lines.add("<p>Residencia: "  + p.getLugarResidencia() + "</p>");
		writeCoordenada(p.getCoordenadasResidencia());
		
		lines.add("<p>"+p.getComentario()+"</p>");
		
		if (!p.getFotos().isEmpty()) {
			lines.add("<h3>Fotos de " + p.getNombre() + " " + p.getApellidos() + "</h3>");
		}
		for (String f : p.getFotos()) {
			lines.add("<img src=\"media/"+f+"\" alt=\""+p.getNombre()+"\">");
		}
		
		if (!p.getVideos().isEmpty()) {
			lines.add("<h3>Videos de " + p.getNombre() + " " + p.getApellidos() + "</h3>");
		}
		for (String v : p.getVideos()) {
			lines.add("<video controls preload=\"auto\">");
			lines.add("<source src=\"media/"+v+"\" type=\"video/"+v.split("\\.")[1]+"\">");
			lines.add("</video>");
		}
	}


	private void writeCoordenada(Coordenada c) {
		lines.add("<ul>"); 
		lines.add("<li>Latitud: " + c.getLatitud() + "</li>");
		lines.add("<li>Longitud: " + c.getLongitud() + "</li>"); 
		lines.add("<li>Altitud: " + c.getAltitud() + " m</li>"); 
		lines.add("</ul>");
	}
	
	

}
