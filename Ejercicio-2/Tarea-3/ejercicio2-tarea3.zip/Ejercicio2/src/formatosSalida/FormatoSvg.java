package formatosSalida;

import java.util.ArrayList;
import java.util.List;

import personas.Persona;

public class FormatoSvg implements Formato {
	
	class Nodo{
		Persona p;
		int row;
		int col;
		boolean hasChildren = true;
		
		public Nodo(Persona p) {
			this.p = p;
		}
		
	
		void setCoordinates(int row, int col) {
			this.row = row;
			this.col = col;
		}
		
		void setCoordinates(int row, int col, boolean children) {
			this.row = row;
			this.col = col;
			this.hasChildren = children;
		}
		
		
	}
	
	private final int ancho = 230;
	private final int alto = 80;
	private final int gapX = 5;
	private final int gapY = 100;

	private List<String> lines;
	
	public FormatoSvg (List<String> lines) {
		this.lines = lines;	
	}
	
	@Override
	public void open(String xmlFile, String cssFile) {
		lines.add("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
		lines.add("<svg version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" " + ">");
	}


	@Override
	public void writeBody(List<Persona> amigos) {
		List<Nodo> arbol = tree(amigos);
		
		for (Nodo n : arbol) {
			writePersona(n);
			writeLines(n);
		}
	}

	private void writeLines(Nodo n) {
		if (n.hasChildren) {
			pathDcha(n);
			pathMedio(n);
			pathIzq(n);
		}
		
	}

	@Override
	public void close() {
		lines.add("</svg>");
	}

	
	private List<Nodo> tree(List<Persona> amigos) {
		List<Nodo>nodos = amigosToNodos(amigos);
		
		//Raiz
		nodos.get(0).setCoordinates(1, 5);	
		
		//Rama Izq
		nodos.get(1).setCoordinates(2, 2);	
		
		nodos.get(2).setCoordinates(3, 1, false);
		nodos.get(3).setCoordinates(3, 2, false);
		nodos.get(4).setCoordinates(3, 3, false);
		
		//Rama Medio
		nodos.get(5).setCoordinates(2, 5);	
		
		nodos.get(6).setCoordinates(3, 4, false);
		nodos.get(7).setCoordinates(3, 5, false);
		nodos.get(8).setCoordinates(3, 6, false);
		
		//Rama Dcha
		nodos.get(9).setCoordinates(2, 8);	
		
		nodos.get(10).setCoordinates(3, 7, false);
		nodos.get(11).setCoordinates(3, 8, false);
		nodos.get(12).setCoordinates(3, 9, false);
		
		return nodos;
	}

	private List<Nodo> amigosToNodos(List<Persona> amigos) {
		List<Nodo> nodos = new ArrayList<>();
		
		for(Persona p: amigos) {
			nodos.add(new Nodo(p));
		}
		
		return nodos;
	}
	
	private void writePersona(Nodo n) {
		int x = (n.col-1)*(ancho+gapX) + gapX;
		int y = (n.row-1)*(alto+gapY) + gapX; 

		lines.add("<rect x=\""+x+"\" y=\""+y+"\" width=\""+ancho+"\" height=\""+alto+"\" style=\"fill:lemonchiffon;stroke:indianred;stroke-width:2\"/>");
		x += 10;
		y += 10;
		lines.add("<text x=\""+x+"\" y=\""+y+"\" font-size=\"10\" style=\"fill:darkslategray\">"+n.p.getNombre() + " " + n.p.getApellidos() +"</text>");
		y += 10;
		lines.add("<text x=\""+x+"\" y=\""+y+"\" font-size=\"8\" style=\"fill:slategray\">"+n.p.getFechaNacimiento() + ": " + n.p.getLugarNacimiento() +"</text>");
		y += 10;
		lines.add("<text x=\""+x+"\" y=\""+y+"\" font-size=\"6\" style=\"fill:slategray\">" + n.p.getCoordenadasNacimiento().toString()+"</text>");
		y += 10;
		lines.add("<text x=\""+x+"\" y=\""+y+"\" font-size=\"8\" style=\"fill:slategray\">"+ "Residencia: " + n.p.getLugarResidencia()+ "</text>");
		y += 10;
		lines.add("<text x=\""+x+"\" y=\""+y+"\" font-size=\"6\" style=\"fill:slategray\">" + n.p.getCoordenadasResidencia().toString()+"</text>");
		y += 10;
		lines.add("<text x=\""+x+"\" y=\""+y+"\" font-size=\"8\" style=\"fill:slategray\">" + "Fotos: "+ n.p.getFotos().toString()+"</text>");
		y += 10;
		lines.add("<text x=\""+x+"\" y=\""+y+"\" font-size=\"8\" style=\"fill:slategray\">" + "Videos: " + n.p.getVideos().toString()+"</text>");
	}
	
	private void pathDcha(Nodo n) {
		String line = "<path d=\"";
		
		//coordenadas iniciales
		int startX = ((n.col-1)*(ancho+gapX) + gapX) + ancho/2;
		int startY = ((n.row-1)*(alto+gapY) + gapX + alto); 
		
		int finalX;
		if(n.row == 1)
			finalX = startX + 3*(ancho+gapX);
		else
			finalX = startX + (ancho+gapX);
		
		int finalY = startY + gapY;
		
		line += "M" + startX + " " + startY + " C" + finalX + " " + startY + " " + startX + " " + finalY + " " + finalX + " " + finalY + "\"";
		line += " style=\"fill:transparent;stroke:indianred\"";
		
		line += "/>";
		
		lines.add(line);
	}

	private void pathIzq(Nodo n) {
		String line = "<path d=\"";
		
		//coordenadas iniciales
		int startX = ((n.col-1)*(ancho+gapX) + gapX) + ancho/2;
		int startY = ((n.row-1)*(alto+gapY) + gapX + alto); 
		
		int finalX;
		if(n.row == 1)
			finalX = startX - 3*(ancho+gapX);
		else
			finalX = startX - (ancho+gapX);
		
		int finalY = startY + gapY;
		
		line += "M" + startX + " " + startY + " C" + finalX + " " + startY + " " + startX + " " + finalY + " " + finalX + " " + finalY + "\"";
		line += " style=\"fill:transparent;stroke:indianred\"";
		
		line += "/>";
		lines.add(line);
	}
	
	private void pathMedio(Nodo n) {
		String line = "<path d=\"";
		
		//coordenadas iniciales
		int startX = ((n.col-1)*(ancho+gapX) + gapX) + ancho/2;
		int startY = ((n.row-1)*(alto+gapY) + gapX + alto); 
		
		int finalX = startX;
		
		int finalY = startY + gapY;
		
		line += "M" + startX + " " + startY + " C" + finalX + " " + startY + " " + startX + " " + finalY + " " + finalX + " " + finalY + "\"";
		line += " style=\"fill:transparent;stroke:indianred\"";
		
		line += "/>";
		lines.add(line);
	}
}
