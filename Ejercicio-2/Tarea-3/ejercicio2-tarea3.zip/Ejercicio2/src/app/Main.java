package app;
import java.io.InputStream;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		InputStream stream = System.in;
		Scanner scan = new Scanner(stream);
		System.out.println("Los archivos multimedia deber�n estar en una carpeta llamada media.");
		String format, xml, output, css = "";

		do{
			System.out.println("Introduce el archivo xml (.xml): ");
			xml = scan.next();
		} while (!xml.split("\\.")[1].equals("xml"));
		
		do {
			System.out.println("Introduce el nombre del archivo de salida (.html, .kml o .svg): ");
			output = scan.next();
			format = output.split("\\.")[1];
		} while(!output.split("\\.")[1].equals("html") && !output.split("\\.")[1].equals("kml") && !output.split("\\.")[1].equals("svg") );
		
		if (format.equals("html")) {
			do{
				System.out.println("Introduce el nombre del archivo css (.css): ");
				css = scan.next();
			} while(!css.split("\\.")[1].equals("css"));
		}
		
		scan.close();
		Application a = new Application(format, xml, output, css);
		a.execute();
	}
}
